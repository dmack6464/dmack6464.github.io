                    ==============================
--------------------|  D Mack's NFMM Stage Pack  |--------------------
                    ==============================

            Delete this file when you copy over this folder
                    to your NFMM install directory.

                             How to copy:
        Copy this folder's contents, including the "mymusic"
       folder into your "mystages" folder, and you're all set!

        I have more stages, but they're particularly crappy.

                (These stages are NOT AI friendly!)

            Stay tuned for more stages and stage packs!

           Discord: D Mack#4481     Twitter: @dmack1012